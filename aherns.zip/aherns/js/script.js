// remove the header
    // var header=parent.document.getElementsByClassName('page_header');
    // header[0].style.display='none'
    // console.log(header);

    function createLIST() {

        // url to spreadsheet
        var url = "https://spreadsheets.google.com/feeds/list/1a00YuGgCNuzYfw7C4qxvpdlbRRiDHV45gPWwQ7E6X0E/o11yyjo/public/values?alt=json";

        //var url = "https://spreadsheets.google.com/feeds/list/" + spreadsheetID + "/o11yyjo/public/values?alt=json";

        $.getJSON(url, function(data) {
            var entry = data.feed.entry;
            //function(){$('ul.chzn-results').empty();},
            $(entry).each(function() {
                // add each option
                //Option = "<li class="active-result">" + this.gsx$list.$t + "</li>";
                //$('ul.chosen-results').append(Option);
                //console.log(this.gsx$list.$t);
                if (this.gsx$list.$t != null) {
                    Option = "<option>" + this.gsx$list.$t + "</option>";
                };

                $('#products').append(Option);
            });
            // Single select example if using params obj or configuration seen above
            var configParamsObj = {
                placeholder: 'Select an option...', // Place holder text to place in the select
                minimumResultsForSearch: 100 // Overrides default of 15 set above
            };
            //$("#products").select2(configParamsObj);
            $('select option')
                .filter(function() {
                    return $.trim(this.text).length == 0;
                })
                .remove();

            var ua = navigator.userAgent.toLowerCase();
            if (ua.indexOf("iphone") > -1 || ua.indexOf("ipad") > -1) {


                var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
                var ver = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
                if (ver[0] >= 8) {
                    $('#products').chosen({ width: '100%' });
                    document.getElementById('qty').style.width = '65%';
                    document.getElementById('qty').style.height = '33px';
                    document.getElementById('input').style.width = '88%';
                    document.getElementById('input').style.height = '33px';
                  
                    document.getElementById('qty').style.fontSize  = '16px';
                    document.getElementById('input').style.marginLeft = '2px';
                     document.getElementById("OtherButton").style.textAlign  = 'left';
                     document.getElementById("emailButton").style.paddingLeft  = 'left';
                     document.getElementById("SMSButton").style.paddingLeft  = 'left';
                     document.getElementById("deleteALLButton").style.paddingLeft  = 'left';
                 

                   
                    //$("#products").select2(configParamsObj);
                //     $('#products').chosen({
                //     width: '100%'
                // });
                } else {
                    $('#products').chosen({ width: '100%' });
                   // $("#products").select2(configParamsObj);
                   document.getElementById('qty').style.width = '65%';
                   document.getElementById('qty').style.height = '33px';
                   document.getElementById('input').style.height = '33px';
                    
                   document.getElementById('qty').style.fontSize  = '16px';
                   document.getElementById('input').style.width = '88%';
                   document.getElementById('input').style.marginLeft = '2px';
                    document.getElementById("OtherButton").style.textAlign  = 'left';
                     document.getElementById("emailButton").style.paddingLeft  = 'left';
                     document.getElementById("SMSButton").style.paddingLeft  = 'left';
                     document.getElementById("deleteALLButton").style.paddingLeft  = 'left';
                         // padding-left: 0px;
               
                }


            } else
              //$("#products").select2(configParamsObj);
                $('#products').chosen({
                    width: '100%'
                });





        });
    }


    // function createLIST(){ 

    //    // url to spreadsheet
    //   var url = "https://spreadsheets.google.com/feeds/list/1a00YuGgCNuzYfw7C4qxvpdlbRRiDHV45gPWwQ7E6X0E/o11yyjo/public/values?alt=json";

    //   $.getJSON(url, function(data) {

    //     var entry = data.feed.entry;

    //     $(entry).each(function(){
    //       // add each option
    //       Option = "<option>" + this.gsx$list.$t + "</option>";
    //               $('#products-list').append(Option);

    //     });

    //   });

    // }

    //---------------------------------------------------------------
    function clearLIST() {
        // clear the predictive text list
        input.style.display = 'block';
        document.getElementsByClassName('select2-drop').style.display = 'none';
        // .select2-container
        var elements = document.getElementsByClassName('select2-container');
        for (var i = 0; i < elements.length; i++) {
            elements[i].style.display = 'none';
        }
        document.getElementById('products_chosen').style.display = 'none';
        document.getElementById('products').style.display = 'none';

        input.setAttribute('list', 'none');

    }
    //---------------------------------------------------------------
    function restoreLIST() {
        // restore the predictive text list
        input.style.display = 'none';

        document.getElementsByClassName('select2-drop').style.display = 'block';
        var elements = document.getElementsByClassName('select2-container');
        for (var i = 0; i < elements.length; i++) {
            elements[i].style.display = 'block';
        }
        document.getElementById('products_chosen').style.display = 'block';
        document.getElementById('products').style.display = 'none';

        input.setAttribute('list', 'products');

        //input.hide()
    }
    //---------------------------------------------------------------
var c = 1;
    //---------------------------------------------------------------
    function addOTHERText() {

        var input1 = document.getElementById('qty').value;
        var input2 = document.getElementById('input').value;
        var input = input1 + ' ' + input2;
        var node = document.createElement("P");
        node.setAttribute('id', 'OTHER' + c);

        // add checkbox
        var checkbox = document.createElement('input');
        checkbox.setAttribute('type', 'checkbox');
        checkbox.setAttribute('value', 'value');
        checkbox.style.marginRight = "20px";
        node.appendChild(checkbox);


        // add test
        var textnode = document.createTextNode(input);
        node.appendChild(textnode);

        // add delete button
        var removenode = document.createElement("input");
        removenode.setAttribute('type', 'button');
        removenode.setAttribute('value', 'X');
        removenode.style.marginLeft = "20px";
        removenode.setAttribute("onclick", "removeText('OTHER" + c + "')");
        node.appendChild(removenode);
        localStorage.setItem('OTHER' + c, input);
        c++;
        document.getElementById('do').appendChild(node);

        //Now Clear both inputs
        document.getElementById("qty").value = "";
        document.getElementById("input").value = "";

        // add strikeout text when checkbox is clicked
        $('[type="checkbox"]').click(function() {
            var element = $(this).parent();
            if ($(this).is(':checked')) {
                element.addClass('line-through');
                //element.wrap('<del>');
            } else {
                element.removeClass('line-through');
                //element.unwrap('<del>');
            }

        });


    }
    //object as seen below
    $.fn.select2.defaults = $.extend($.fn.select2.defaults, {
        allowClear: true, // Adds X image to clear select
        closeOnSelect: true, // Only applies to multiple selects. Closes the select upon selection.
        placeholder: 'Select...',
        minimumResultsForSearch: 15 // Removes search when there are 15 or fewer options
    });

    //---------------------------------------------------------------
    function addText() {
       // alert("sad");
        var input1 = document.getElementById('qty').value;
        var input2 = document.getElementById('input').value;
        // alert(input2);
        if (input2.length == 0) {
            //if (empty(input2)) {
            //if (input2 == null){
            var input2 = document.getElementById('products').value;
        };


        var input = input1 + ' ' + input2;

        var node = document.createElement("P");
        node.setAttribute('id', 'ShoppingListStorage' + c);

        // add checkbox
        var checkbox = document.createElement('input');
        checkbox.setAttribute('type', 'checkbox');
        checkbox.setAttribute('value', 'value');
        checkbox.style.marginRight = "20px";

        node.appendChild(checkbox);



        // add test
        var textnode = document.createTextNode(input);
        node.appendChild(textnode);


        // add delete button
        var removenode = document.createElement("input");

        removenode.setAttribute('type', 'button');
        removenode.setAttribute('value', 'X');
        removenode.style.marginLeft = "20px";
        removenode.setAttribute("onclick", "removeText('ShoppingListStorage" + c + "')");
        node.appendChild(removenode);

        localStorage.setItem('ShoppingListStorage' + c, input);
         //alert(node);

        c++;
        document.getElementById('do').appendChild(node);

        //Now Clear both inputs
        document.getElementById("qty").value = "";
        document.getElementById("input").value = "";
        // document.getElementById('products').value= "Select Fruit/Veg";
        // $('#products option').prop('selected', function() {
        //      return this.defaultSelected;
        //  });
        $('#products')
            .find('option:first-child').prop('selected', true)
            .end().trigger('chosen:updated');


        // add strikeout text when checkbox is clicked
        $('[type="checkbox"]').click(function() {
            var element = $(this).parent();
            if ($(this).is(':checked')) {
                element.addClass('line-through');
                // element.wrap('<del>');
            }
            // else if(!$(this).is(':checked')) {

            // } 
            else {
                //element.unwrap('<del>');
                element.removeClass('line-through');
            }

        });


    }

    function removeText(item) {
        var child = document.getElementById(item);
        document.getElementById('do').removeChild(child);
        localStorage.removeItem(item);
    }

    //--------------------------------------------------------------
    function AHERNlistLoad() {

        // clear all list items
        var myNode = document.getElementById("do");
        myNode.innerHTML = '';

        //change onclick function of add button
        document.getElementById("button").onclick = addText;

        //change the email onclick function button
        document.getElementById("emailButton").onclick = openAhernEmail;
        document.getElementById("SMSButton").onclick = openSMS;

        //change the delete All list button
        document.getElementById("deleteALLButton").onclick = deleteALLAhern;

        // change the button colours
        document.getElementById("AhernButton").style.backgroundColor = 'lightblue';
        document.getElementById("OtherButton").style.backgroundColor = 'transparent';


        // document.getElementById("products_chosen").style.width = '100%';

        // Update the placeholder text in input
        //document.getElementsByName('input')[0].placeholder='Select Fruit/Veg';

        //document.getElementById("div1").classList.add("safari-display");
        // $('#input').addClass("chrome-display");
        // $('#products-list').removeClass("chrome-display");
        document.getElementById('input').style.display = 'none';

        //add the Google spreadsheet list
        //restoreLIST();


        // input.style.display = 'none';

        // document.getElementsByClassName('select2-drop').style.display = 'block';
        //  var elements = document.getElementsByClassName('select2-container');
        //for(var i=0; i<elements.length; i++) { 
        //  elements[i].style.display='block';
        //}

        // document.getElementById('products_chosen').style.display = 'block';
        //document.getElementById('products').style.display = 'none';
        //input.style.display = 'none';
        //alert('dad');


        if (localStorage.length) {
            for (var index = 0; index < localStorage.length; index++) {
                // alert(localStorage.key(index));
                // check to see if its one of our shopping list items
                if (localStorage.key(index).indexOf('ShoppingListStorage') >= 0) {
                    // Found a match! so add a record to list
                    //alert("FOUND A ShoppingListStorage MATCH!!!");
                    //AddText via localStorage
                    var input = localStorage.getItem(localStorage.key(index));

                    var node = document.createElement("P");
                    node.setAttribute('id', localStorage.key(index));

                    // add checkbox
                    var checkbox = document.createElement('input');
                    checkbox.setAttribute('type', 'checkbox');
                    checkbox.setAttribute('value', 'value');
                    checkbox.style.marginRight = "20px";
                    checkbox.setAttribute('id', localStorage.key(index));
                    node.appendChild(checkbox);

                    //add text element
                    var textnode = document.createTextNode(input);
                    node.appendChild(textnode);

                    // add delete button
                    var removenode = document.createElement("input");
                    removenode.setAttribute('type', 'button');
                    removenode.setAttribute('value', 'X');
                    removenode.style.marginLeft = "20px";
                    removenode.setAttribute("onclick", "removeText('" + localStorage.key(index) + "')");
                    node.appendChild(removenode);
                    c++;
                    document.getElementById('do').appendChild(node);
                    //
                } // this is end of IF statement

            }
        } else {
            //localStorage == null
        }


        // add strikeout text when checkbox is clicked
        $('[type="checkbox"]').click(function() {
            var element = $(this).parent();
            if ($(this).is(':checked')) {
                //element.wrap('<del>');
                element.addClass('line-through');
            } else {
                //element.unwrap('<del>');
                element.removeClass('line-through');
            }


        });
        document.getElementById('products').style.display = 'block';
        document.getElementById('products_chosen').style.display = 'block';
        document.getElementById('products').style.display = 'none';

        restoreLIST()

    }

    //--------------------------------------------------------------
    function OTHERlistLoad() {

        // clear all list items
        var myNode = document.getElementById("do");
        myNode.innerHTML = '';

        //change onclick function of add button
        document.getElementById("button").onclick = addOTHERText;

        //change the email onclick function button
        document.getElementById("emailButton").onclick = openOTHEREmail;
        document.getElementById("SMSButton").onclick = openotherSMS;


        //change the delete All list button
        document.getElementById("deleteALLButton").onclick = deleteALLOTHER;

        // change the button colours
        document.getElementById("AhernButton").style.backgroundColor = 'transparent';
        document.getElementById("OtherButton").style.backgroundColor = 'lightblue';

        // Update the placeholder text in input
        document.getElementsByName('input')[0].placeholder = 'Add item';

        // $('#input').removeClass('chrome-display');
        // $('#products').hide();

        //clear the list
        // input.style.display = 'block';
        // document.getElementsByClassName('select2-drop').style.display = 'none';
        // .select2-container
        // var elements = document.getElementsByClassName('select2-container');
        //for(var i=0; i<elements.length; i++) { 
        //  elements[i].style.display='none';
        //}

        //document.getElementById("products").style.display = 'none';

        //document.getElementById('products_chosen').style.display = 'none';


        if (localStorage.length) {
            for (var index = 0; index < localStorage.length; index++) {
                // alert(localStorage.key(index));
                // check to see if its one of our shopping list items
                if (localStorage.key(index).indexOf('OTHER') >= 0) {
                    // Found a match! so add a record to list
                    //alert("FOUND A MATCH!!!");
                    //AddText via localStorage
                    var input = localStorage.getItem(localStorage.key(index));

                    var node = document.createElement("P");
                    node.setAttribute('id', localStorage.key(index));

                    // add checkbox
                    var checkbox = document.createElement('input');
                    checkbox.setAttribute('type', 'checkbox');
                    checkbox.setAttribute('value', 'value');
                    checkbox.style.marginRight = "20px";
                    checkbox.setAttribute('id', localStorage.key(index));
                    node.appendChild(checkbox);

                    //add text element
                    var textnode = document.createTextNode(input);
                    node.appendChild(textnode);

                    // add delete button
                    var removenode = document.createElement("input");
                    removenode.setAttribute('type', 'button');
                    removenode.setAttribute('value', 'X');
                    removenode.style.marginLeft = "20px";
                    removenode.setAttribute("onclick", "removeText('" + localStorage.key(index) + "')");
                    node.appendChild(removenode);
                    c++;
                    document.getElementById('do').appendChild(node);
                    //
                } // this is end of IF statement
            }
        } else {
            //localStorage == null
        }


        // add strikeout text when checkbox is clicked
        $('[type="checkbox"]').click(function() {
            var element = $(this).parent();
            if ($(this).is(':checked')) {
                // element.wrap('<del>');
                element.addClass('line-through');
            } else {
                //element.unwrap('<del>');
                element.removeClass('line-through');
            }


        });
        document.getElementById('products').style.display = 'none';
        document.getElementById('input').style.display = 'block';
        document.getElementById('products_chosen').style.display = 'none';
        clearLIST()

    }


    

    function popup() {
      var title = "Question";
      var html = "Are you sure you want to clear the list?";
      $dialog.html(html);
      $dialog.dialog({
        title: title,
        resizable: false,
        buttons: {
          " Yes ": function() {
            $( this ).dialog( "close" );
            //yes_function();
             //return true;
              callback(true);
          },
          " No ": function() {
            $( this ).dialog( "close" );
            //no_function();
            callback(false);
            //return false;
          }
        }
      });
      
    }

    function popup_other() {
      var title = "Question";
      var html = "Are you sure you want to clear the list?";
      $dialog.html(html);
      $dialog.dialog({
        title: title,
        resizable: false,
        buttons: {
          " Yes ": function() {
            $( this ).dialog( "close" );
            //yes_function();
             //return true;
              callback_other(true);
          },
          " No ": function() {
            $( this ).dialog( "close" );
            //no_function();
            callback_other(false);
            //return false;
          }
        }
      });
      
    }


    function yes_function() {
        //alert('Yes');
        return 1;
    }
    function no_function() {
       // alert('No');
        return 2;
    }



    function callback(value){
         //do something
         if (value == true) {
         var x;
         var myNode = document.getElementById("do");
            myNode.innerHTML = '';

            // remove the local storage
            for (var index = 0; index < localStorage.length; index++) {

                // check to see if its one of our shopping list items
                if (localStorage.key(index).indexOf('ShoppingListStorage') >= 0) {

                    localStorage.removeItem(localStorage.key(index));
                } else {
                    //alert(localStorage.key(index) + " not ShoppingListStorage ")
                }
            }
          }
          else {

          }
    }


    //----------------------------------------------------------------
    // prompt box for first time user
    function termsCondition() {
        var x;
        popup_message();
        

    }
    function popup_message() {
      var title = "Information";
      var html = "For an explanation of how to use the shopping list features please refer to the built-in 'App User Guide' in the app menu.";
      $dialog.html(html);
      $dialog.dialog({
        title: title,
        resizable: false,
        buttons: {
          " Got it ": function() {
            $( this ).dialog( "close" );
            //yes_function();
             //return true;
              //callback(true);
          },
          // " No ": function() {
          //   $( this ).dialog( "close" );
          //   //no_function();
          //   callback(false);
          //   //return false;
          // }
        }
      });
      
    }
    //----------------------------------------------------------------
    // prompt box for delete ALL Ahern list
    function deleteALLAhern() {
        var x;
        popup();
        

    }
    function callback_other(value){
         //do something
         if (value == true) {
         var x;
         var myNode = document.getElementById("do");
            myNode.innerHTML = '';

            // remove the local storage
            for (var index = 0; index < localStorage.length; index++) {

                // check to see if its one of our shopping list items
                if (localStorage.key(index).indexOf('OTHER') >= 0) {

                    localStorage.removeItem(localStorage.key(index));
                } else {
                    //alert(localStorage.key(index) + " not OTHER ")
                }
            }
          }
          else {

          }
    }
    //----------------------------------------------------------------
    // prompt box for delete ALL Ahern list
    function deleteALLOTHER() {
        var x;
        popup_other();
        // if (window.confirm("Are you sure you want to delete all the items on this list?") == true) {
        //     //alert('Confirmed - currently only clearing list and not local storage - to be completed');
        //     // clear all list items
        //     var myNode = document.getElementById("do");
        //     myNode.innerHTML = '';

        //     // remove the local storage
        //     for (var index = 0; index < localStorage.length; index++) {

        //         // check to see if its one of our shopping list items
        //         if (localStorage.key(index).indexOf('OTHER') >= 0) {

        //             localStorage.removeItem(localStorage.key(index));
        //         } else {
        //             //alert(localStorage.key(index) + " not OTHER ")
        //         }
        //     }


        // } else { //closing first IF from prompt
        //     // no nothing
        // }

    }
    //----------------------------------------------------------------
    function openAhernEmail() {

        // clear all list items
        //var myNode = document.getElementById("do");
        //myNode.innerHTML = '';
        var EmailMessage = "Can you please get the following items from Aherns:" + String.fromCharCode(13);

        // remove the local storage
        for (var index = 0; index < localStorage.length; index++) {

            // check to see if its one of our shopping list items
            if (localStorage.key(index).indexOf('ShoppingListStorage') >= 0) {

                // get the key and value to add to email list
                var key = localStorage.key(index);
                var value = localStorage[key];
                
                // case_history = localStorage.getItem("line-through");
                // console.log(case_history);
                // // <span style="text-decoration: underline;font-style: italic; font-weight: bold;"> Underlined,bold and italic</span>
                // if (case_history != null){
                //   value = "<span style='text-decoration: line-through;'>"+case_history+"</span>"
                // }

                //alert(value);
                //str = str.replace(new RegExp(String.fromCharCode(13), 'g'), '\r\n');
                EmailMessage = EmailMessage + '\n' + value;
                // EmailMessage = EmailMessage.replace(new RegExp(String.fromCharCode(13), 'g'), '\r\n');
            } else {
                //alert(localStorage.key(index) + " not ShoppingListStorage ")
            }
        }


        //alert("openEmail");
        var yourMessage = EmailMessage;
        var subject = "Aherns Shopping List"; //document.getElementById("selectList").value;
        document.location.href = "mailto:?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(yourMessage);

    }

    //----------------------------------------------------------------
    function openOTHEREmail() {

        // clear all list items
        //var myNode = document.getElementById("do");
        //myNode.innerHTML = '';
        var EmailMessage = "Can you please get the following items:" + String.fromCharCode(13) + String.fromCharCode(13);

        // remove the local storage
        for (var index = 0; index < localStorage.length; index++) {

            // check to see if its one of our shopping list items
            if (localStorage.key(index).indexOf('OTHER') >= 0) {

                // get the key and value to add to email list
                var key = localStorage.key(index);
                var value = localStorage[key];

                //alert(value);
                EmailMessage = EmailMessage + '\n' + value;
            } else {
                //alert(localStorage.key(index) + " not ShoppingListStorage ")
            }
        }


        //alert("openEmail");
        var yourMessage = EmailMessage;
        var subject = "Shopping List"; //document.getElementById("selectList").value;
        document.location.href = "mailto:?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(yourMessage);

    }

    //----------------------------------------------------------------
    function openSMS() {



        var EmailMessage = "Can you please get the following items from Aherns:" + String.fromCharCode(13);
        // remove the local storage
        for (var index = 0; index < localStorage.length; index++) {

            // check to see if its one of our shopping list items
            if (localStorage.key(index).indexOf('ShoppingListStorage') >= 0) {

                // get the key and value to add to email list
                var key = localStorage.key(index);
                var value = localStorage[key];

                //alert(value);
                if (index != localStorage.length - 1) {
                      // build the new query
                      EmailMessage = EmailMessage + value +','+ String.fromCharCode(13);
                     // NewQuery += QuerySplit[i].value + " AND "
                } else {
                     // NewQuery += QuerySplit[i].value;
                      EmailMessage = EmailMessage + value +'.'+  String.fromCharCode(13);
                }
                
            } else {
                //alert(localStorage.key(index) + " not ShoppingListStorage ")
            }
        }
        //   var ua = navigator.userAgent.toLowerCase();
        var url;

        // if (ua.indexOf("iphone") > -1 || ua.indexOf("ipad") > -1)
        //     url = "sms:+;body="+EmailMessage;

        // else
        //     url = "sms:+?body="+EmailMessage;

        var ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("iphone") > -1 || ua.indexOf("ipad") > -1) {


            var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
            var ver = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
            if (ver[0] >= 8) {
                url = "sms:?&body=" + EmailMessage;
            } else {
                url = "sms:;body=" + EmailMessage;
            }


        } else
            url = "sms:?body=" + EmailMessage;

        //location.href = url;
         window.open(url, '_system');
        //window.open (url);



        //      //alert("openEmail");
        //      var yourMessage = EmailMessage;
        //       // sms:?body=Hello%20World!
        //window.location.href = "sms:?&body=" + EmailMessage;
        //alert("openSMS");
        // window.open('sms:+0987654321?body=Can you please get the following items from Aherns: 4 Apples , 2 Banana , 3 Strawberries', '_system');
        //  window.location.href = "Can you please get the following items from Ahern  please: ";

        // var subject = "Aherns Shopping List"; //document.getElementById("selectList").value;
        // document.location.href = "mailto:?subject="
        //   + encodeURIComponent(subject)
        //   + "&body=" + encodeURIComponent(yourMessage);


    }
    //----------------------------------------------------------------
    function openotherSMS() {



        var EmailMessage = "Can you please get the following items from Aherns:" + String.fromCharCode(13);
        // remove the local storage
       // $arraySize = count(localStorage.length);
        for (var index = 0; index < localStorage.length; index++) {

            // check to see if its one of our shopping list items
            if (localStorage.key(index).indexOf('OTHER') >= 0) {

                // get the key and value to add to email list
                var key = localStorage.key(index);
                var value = localStorage[key];

                //alert(value);
                if (index != localStorage.length - 1) {
                      // build the new query
                      EmailMessage = EmailMessage + value +','+ String.fromCharCode(13);
                     // NewQuery += QuerySplit[i].value + " AND "
                } else {
                     // NewQuery += QuerySplit[i].value;
                      EmailMessage = EmailMessage + value +'.'+ String.fromCharCode(13);
                }
            } else {
                //alert(localStorage.key(index) + " not ShoppingListStorage ")
            }
        }

        //      var ua = navigator.userAgent.toLowerCase();
        var url;

        // if (ua.indexOf("iphone") > -1 || ua.indexOf("ipad") > -1)
        //     url = "sms:+;body="+EmailMessage;
        // else
        //     url = "sms:+?body="+EmailMessage;

        var ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf("iphone") > -1 || ua.indexOf("ipad") > -1) {


            var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
            var ver = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
            if (ver[0] >= 8) {
                url = "sms:?&body=" + EmailMessage;
            } else {
                url = "sms:;body=" + EmailMessage;
            }


        } else
            url = "sms:?body=" + EmailMessage;


        // navigator.app.loadUrl(url, {openExternal : true});
        //window.open(url, '_blank');
        window.open(url, '_system');
         //window.location = url;
     

        //document.location.href = url;
        //window.open (url);
        //webview.loadUrl(url);
        //steroids.openURL(url);


        //      //alert("openEmail");
        //      var yourMessage = EmailMessage;
        // sms:?body=Hello%20World!
        //window.location.href = "sms:?body=Hello%20World!";
        // alert("openSMS");
        // window.open('sms:+0987654321?body=Can you please get the following items from Aherns: 4 Apples , 2 Banana , 3 Strawberries', '_system');
        //  window.location.href = "Can you please get the following items from Ahern  please: ";

        // var subject = "Aherns Shopping List"; //document.getElementById("selectList").value;
        // document.location.href = "mailto:?subject="
        //   + encodeURIComponent(subject)
        //   + "&body=" + encodeURIComponent(yourMessage);


    }